// Minimal Node/Express server with file-backed users and socket.io for connected users
const express = require('express');
const fs = require('fs');
const path = require('path');
const http = require('http');
const app = express();
const server = http.createServer(app);
const { Server } = require('socket.io');
const io = new Server(server);

const USERS_FILE = path.join(__dirname,'users.json');
function readUsers(){ try{ const raw = fs.readFileSync(USERS_FILE,'utf8'); return JSON.parse(raw||'[]'); }catch(e){ return [] } }
function writeUsers(list){ fs.writeFileSync(USERS_FILE, JSON.stringify(list,null,2)); }

app.use(express.json());
app.use(express.static(path.join(__dirname,'public'))); // serve index.html from public

// API: sign up
app.post('/api/signup', (req,res)=>{
  const { name, email, password } = req.body || {};
  if(!name || !email || !password) return res.status(400).json({ error: 'Missing fields' });
  const users = readUsers();
  if(users.find(u=>u.email === email)) return res.status(409).json({ error: 'Email already taken' });
  // NOTE: For demo only: store plain password (DO NOT do this in production!)
  const user = { id: Date.now().toString(36), name, email, password };
  users.push(user);
  writeUsers(users);
  res.json({ ok:true, user: { id: user.id, name: user.name, email: user.email } });
});

// API: login
app.post('/api/login', (req,res)=>{
  const { email, password } = req.body || {};
  if(!email || !password) return res.status(400).json({ error: 'Missing fields' });
  const users = readUsers();
  const user = users.find(u=>u.email === email && u.password === password);
  if(!user) return res.status(401).json({ error: 'Invalid credentials' });
  // return user basic data — in a real app return a token
  res.json({ ok:true, user: { id: user.id, name: user.name, email: user.email } });
});

// WebSocket: track connected clients
const connected = new Map();
io.on('connection', socket=>{
  socket.on('auth', ({ id, name })=>{
    // id should be unique (email). keep a simple record
    connected.set(socket.id, { socketId: socket.id, id, name, connectedAt: Date.now() });
    // broadcast updated list
    broadcastConnected();
  });
  socket.on('disconnect', ()=>{
    connected.delete(socket.id);
    broadcastConnected();
  });
});

function broadcastConnected(){
  const list = Array.from(connected.values()).map(u=>({ id:u.id, name:u.name }));
  io.emit('connected-list', list);
}

// Serve index.html at root (we assume user placed index.html into ./public)
app.get('/', (req,res)=>{
  res.sendFile(path.join(__dirname,'public','index.html'));
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, ()=> console.log('Server running on http://localhost:'+PORT));